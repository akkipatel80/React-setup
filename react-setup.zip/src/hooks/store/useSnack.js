import { create } from "zustand";

export const useSnack = create((set) => ({
  message: "",
  type: "",
  open: false,
  setSnack(message = "", type = "success", open = true) {
    setTimeout(() => {
      set(() => ({
        message,
        type,
        open,
      }));
    });
  },
  closeSnack() {
    set(() => ({ message: "", type: "", open: false }));
  },
}));
