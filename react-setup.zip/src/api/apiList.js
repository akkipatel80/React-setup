export const APIS = {
  AUTHENTICATION: {
    SIGNUP: "/user/add",
    SIGNIN: "/user/login",
  },
};
