import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Home from "./pages/Home";
import ErrorBoundary from "./Component/ErrorBoundary";

const routes = createBrowserRouter([{ path: "/", Component: Home }]);

export default function Routes() {
  return (
    <ErrorBoundary>
      <RouterProvider router={routes} fallbackElement="loading" />
    </ErrorBoundary>
  );
}
