import React from "react";

export default function Home() {
  return <div className="text-xl text-gray-900">Home</div>;
}
